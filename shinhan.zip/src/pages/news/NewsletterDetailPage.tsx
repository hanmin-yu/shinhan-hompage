import styled from '@emotion/styled';
import { useEffect, useState } from 'react';
import { Navigate, useParams } from 'react-router-dom';

import { LandingSubnav } from '../../components/site/LandingSubnav';
import * as P from '../../components/site/PagePrimitives';
import { palette } from '../../components/home/homeStyles';
import { useSiteContent } from '../../hooks/useSiteContent';
import { useNewsletterRecord, useNewsletterRecords } from '../../hooks/useNewsContent';
import { useI18n } from '../../i18n/useI18n';
import { getNewsletterDownloadFileName } from '../../utils/newsletter';
import { downloadFileFromUrl } from '../../utils/downloadFile';
import { NewsFlushPageSection, NewsHeroSection, NewsPageContainer } from './newsLayout';

type NewsletterManifest = {
  slug: string;
  pdf?: string | null;
  images: string[];
};

const ContentBlock = styled.div`
  margin-top: 12px;
`;

const ViewerWrap = styled.div`
  padding: clamp(16px, 2.4vw, 24px);
  border-radius: 18px;
  border: 1px solid rgba(20, 75, 157, 0.18);
  background: linear-gradient(180deg, #f9fbff, #eef4fb);
  box-shadow: 0 24px 44px rgba(13, 44, 92, 0.08);
`;

const ViewerHeader = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  justify-content: space-between;
  gap: 14px;
  margin-bottom: 18px;
`;

const ActionRow = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 10px;
`;

const DownloadLink = styled.a`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 40px;
  padding: 0 15px;
  border-radius: 6px;
  border: 1px solid rgba(20, 75, 157, 0.2);
  background: #f7fbff;
  color: #1b56a8;
  font-size: 0.88rem;
  font-weight: 700;
`;

const ViewerControls = styled.div`
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 10px;
`;

const NavButton = styled.button<{ $primary?: boolean }>`
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 110px;
  min-height: 42px;
  padding: 0 14px;
  border-radius: 999px;
  border: 1px solid ${({ $primary }) => ($primary ? 'rgba(19, 81, 174, 0.3)' : 'rgba(19, 75, 154, 0.18)')};
  background: ${({ $primary }) => ($primary ? 'linear-gradient(180deg, #2567c2, #174d9a)' : '#ffffff')};
  color: ${({ $primary }) => ($primary ? '#ffffff' : '#1b4f95')};
  font-size: 0.9rem;
  font-weight: 700;
  cursor: pointer;

  &:disabled {
    opacity: 0.45;
    cursor: default;
  }
`;

const PageCounter = styled.div`
  min-width: 96px;
  color: #173f77;
  font-size: 0.93rem;
  font-weight: 800;
  text-align: center;
`;

const ViewerStage = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 68vh;
  padding: clamp(12px, 2vw, 20px);
  border-radius: 16px;
  background:
    radial-gradient(circle at top, rgba(54, 110, 191, 0.12), transparent 32%),
    linear-gradient(180deg, #dfe9f7, #edf3fb 22%, #dde8f7 100%);
  border: 1px solid rgba(20, 75, 157, 0.14);

  @media (max-width: 820px) {
    min-height: 50vh;
  }
`;

const PageImage = styled.img`
  width: min(100%, 980px);
  height: auto;
  border-radius: 10px;
  background: #ffffff;
  box-shadow: 0 26px 50px rgba(14, 36, 77, 0.16);
`;

const PdfFrame = styled.iframe`
  display: block;
  width: 100%;
  height: min(78vh, 920px);
  min-height: 640px;
  border: 1px solid rgba(20, 75, 157, 0.14);
  border-radius: 12px;
  background: #ffffff;
  box-shadow: 0 24px 44px rgba(14, 36, 77, 0.12);

  @media (max-width: 820px) {
    height: 68vh;
    min-height: 520px;
  }
`;

const ThumbnailRail = styled.div`
  display: grid;
  grid-auto-flow: column;
  grid-auto-columns: minmax(88px, 108px);
  gap: 10px;
  overflow-x: auto;
  margin-top: 16px;
  padding-bottom: 4px;
`;

const ThumbnailButton = styled.button<{ $active: boolean }>`
  display: grid;
  gap: 6px;
  padding: 8px;
  border-radius: 12px;
  border: 1px solid ${({ $active }) => ($active ? 'rgba(20, 75, 157, 0.36)' : 'rgba(20, 75, 157, 0.12)')};
  background: ${({ $active }) => ($active ? 'rgba(234, 242, 255, 0.9)' : 'rgba(255, 255, 255, 0.82)')};
  cursor: pointer;
`;

const ThumbnailImage = styled.img`
  width: 100%;
  height: 110px;
  object-fit: cover;
  border-radius: 8px;
  background: #ffffff;
`;

const ThumbnailLabel = styled.span`
  color: ${palette.blue};
  font-size: 0.78rem;
  font-weight: 700;
  text-align: center;
`;

export function NewsletterDetailPage() {
  const { t } = useI18n();
  const { content } = useSiteContent();
  const newsSubnav = content.global.sectionSubnav.news;
  const { newsletterId } = useParams<{ newsletterId: string }>();

  const { item, loading: loadingItem } = useNewsletterRecord(newsletterId);
  const { items: allNewsletterItems } = useNewsletterRecords();
  const [manifest, setManifest] = useState<NewsletterManifest | null>(null);
  const [loadingPreview, setLoadingPreview] = useState(false);
  const [activePageIndex, setActivePageIndex] = useState(0);

  const previewManifestUrl = item?.previewManifestUrl ?? null;
  const previewBasePath = previewManifestUrl?.replace(/\/manifest\.json$/i, '') ?? null;

  useEffect(() => {
    let ignore = false;

    if (!previewManifestUrl) {
      setManifest(null);
      return;
    }

    setLoadingPreview(true);

    fetch(previewManifestUrl)
      .then(async (res) => {
        if (!res.ok) throw new Error('manifest not found');
        const data = (await res.json()) as NewsletterManifest;
        if (!ignore) setManifest(data);
      })
      .catch(() => {
        if (!ignore) setManifest(null);
      })
      .finally(() => {
        if (!ignore) setLoadingPreview(false);
      });

    return () => {
      ignore = true;
    };
  }, [previewManifestUrl]);

  const imageUrls = manifest?.images && previewBasePath ? manifest.images.map((name) => `${previewBasePath}/${name}`) : [];
  const currentImageUrl = imageUrls[activePageIndex] ?? null;

  useEffect(() => {
    setActivePageIndex(0);
  }, [previewManifestUrl, imageUrls.length]);

  useEffect(() => {
    if (!imageUrls.length) return;

    const handleKeydown = (event: KeyboardEvent) => {
      if (event.key === 'ArrowRight') {
        setActivePageIndex((current) => Math.min(current + 1, imageUrls.length - 1));
      }

      if (event.key === 'ArrowLeft') {
        setActivePageIndex((current) => Math.max(current - 1, 0));
      }
    };

    window.addEventListener('keydown', handleKeydown);
    return () => window.removeEventListener('keydown', handleKeydown);
  }, [imageUrls.length]);

  const movePage = (direction: -1 | 1) => {
    setActivePageIndex((current) => Math.min(Math.max(current + direction, 0), imageUrls.length - 1));
  };

  const newsletterDownloadItems = item
    ? [item, ...allNewsletterItems.filter((candidate) => candidate.id !== item.id && candidate.publishedAt === item.publishedAt)]
        .filter((candidate) => Boolean(candidate.downloadUrl))
        .filter((candidate, index, items) => items.findIndex((current) => (current.language ?? current.id) === (candidate.language ?? candidate.id)) === index)
        .sort((left, right) => {
          const languageOrder = (language?: string) => (language === '국문' ? 0 : language === '영문' ? 1 : 2);
          return languageOrder(left.language) - languageOrder(right.language);
        })
    : [];

  if (!loadingItem && !item) {
    return <Navigate to="/news/newsletter" replace />;
  }

  return (
    <>
      <NewsHeroSection>
        <NewsPageContainer>
          <LandingSubnav
            kicker={newsSubnav.kicker}
            kickerEn={newsSubnav.kickerEn}
            title={newsSubnav.title}
            titleEn={newsSubnav.titleEn}
            summary={newsSubnav.summary}
            summaryEn={newsSubnav.summaryEn}
            items={newsSubnav.items}
            matchAboutHero
          />
        </NewsPageContainer>
      </NewsHeroSection>

      <NewsFlushPageSection>
        <NewsPageContainer>
          <ContentBlock data-reveal>
            <ViewerWrap>
              <ViewerHeader>
                <ActionRow>
                  <P.CardLink to="/news/newsletter">{t('소식지 목록', 'Newsletter List')}</P.CardLink>
                  {newsletterDownloadItems.map((downloadItem) => (
                    <DownloadLink
                      key={downloadItem.id}
                      href={downloadItem.downloadUrl}
                      download={
                        downloadItem.downloadFileName ??
                        getNewsletterDownloadFileName(downloadItem.downloadUrl, t(downloadItem.title, downloadItem.titleEn))
                      }
                      onClick={(event) => {
                        const fileName =
                          downloadItem.downloadFileName ??
                          getNewsletterDownloadFileName(downloadItem.downloadUrl, t(downloadItem.title, downloadItem.titleEn));

                        event.preventDefault();
                        void downloadFileFromUrl(downloadItem.downloadUrl!, fileName);
                      }}
                    >
                      {downloadItem.language === '영문' ? t('영문 PDF 다운로드', 'English PDF') : t('국문 PDF 다운로드', 'Korean PDF')}
                    </DownloadLink>
                  ))}
                </ActionRow>
                {imageUrls.length ? (
                  <ViewerControls>
                    <NavButton type="button" onClick={() => movePage(-1)} disabled={activePageIndex === 0}>
                      {t('이전 페이지', 'Previous')}
                    </NavButton>
                    <PageCounter>
                      {t(`${activePageIndex + 1} / ${imageUrls.length} 페이지`, `Page ${activePageIndex + 1} / ${imageUrls.length}`)}
                    </PageCounter>
                    <NavButton
                      type="button"
                      $primary
                      onClick={() => movePage(1)}
                      disabled={activePageIndex === imageUrls.length - 1}
                    >
                      {t('다음 페이지', 'Next')}
                    </NavButton>
                  </ViewerControls>
                ) : null}
              </ViewerHeader>

              {loadingPreview ? <P.CardText>{t('소식지를 불러오는 중입니다...', 'Loading newsletter...')}</P.CardText> : null}

              {!loadingPreview && currentImageUrl ? (
                <>
                  <ViewerStage>
                    <PageImage
                      src={currentImageUrl}
                      alt={`${t(item?.title ?? '', item?.titleEn ?? '')} ${t(`${activePageIndex + 1}페이지`, `page ${activePageIndex + 1}`)}`}
                    />
                  </ViewerStage>

                  <ThumbnailRail aria-label={t('소식지 페이지 목록', 'Newsletter page list')}>
                    {imageUrls.map((src, index) => (
                      <ThumbnailButton
                        key={src}
                        type="button"
                        $active={index === activePageIndex}
                        onClick={() => setActivePageIndex(index)}
                      >
                        <ThumbnailImage
                          src={src}
                          alt={`${t(item?.title ?? '', item?.titleEn ?? '')} ${t(`${index + 1}페이지 미리보기`, `page ${index + 1} preview`)}`}
                          loading="lazy"
                        />
                        <ThumbnailLabel>{t(`${index + 1}페이지`, `Page ${index + 1}`)}</ThumbnailLabel>
                      </ThumbnailButton>
                    ))}
                  </ThumbnailRail>
                </>
              ) : null}

              {!loadingPreview && !imageUrls.length && item?.downloadUrl ? (
                <PdfFrame
                  src={`${item.downloadUrl}#toolbar=1&navpanes=0`}
                  title={t(item.title, item.titleEn)}
                />
              ) : null}

              {!loadingPreview && !imageUrls.length && !item?.downloadUrl ? (
                <P.CardText>
                  {t(
                    'PDF 파일이 아직 연결되지 않았습니다.',
                    'The PDF file is not available yet.',
                  )}
                </P.CardText>
              ) : null}
            </ViewerWrap>
          </ContentBlock>
        </NewsPageContainer>
      </NewsFlushPageSection>
    </>
  );
}
